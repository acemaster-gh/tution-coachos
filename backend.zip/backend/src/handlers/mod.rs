pub mod auth;
pub mod health;
pub mod students;
pub mod parents;
pub mod fees;
pub mod leads;

// Re-export handler functions/types so callers can `use crate::handlers::{health, home}`
pub use auth::*;
pub use health::*;
pub use students::*;
pub use parents::*;
pub use fees::*;
pub use leads::*;